package fi.haagahelia.course;




import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class StudentListSecureInMemoryUsersApplicationTests {

	@Test
	public void contextLoads() {
	}

}
