package fi.haagahelia.filedemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FiledemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(FiledemoApplication.class, args);
	}

}

