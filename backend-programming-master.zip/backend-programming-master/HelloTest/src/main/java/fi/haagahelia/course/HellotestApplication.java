package fi.haagahelia.course;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HellotestApplication {

	public static void main(String[] args) {
		SpringApplication.run(HellotestApplication.class, args);
	}
}
