package fi.haagahelia.filedemo.domain;

import org.springframework.data.repository.CrudRepository;

public interface FileModelRepository extends CrudRepository<FileModel, Long> {

}
