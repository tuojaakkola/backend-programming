package fi.haagahelia.course;


import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
public class SecuritydemoApplicationTests {

	@Test
	public void contextLoads() {
	}

}
