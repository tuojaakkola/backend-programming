package fi.haagahelia.course;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentListRestApplicationTests {

	@Test
	void contextLoads() {
	}

}

