package fi.haagahelia.course;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloFormValidationApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloFormValidationApplication.class, args);
	}
}
